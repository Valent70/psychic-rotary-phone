VERIQO AUDITOR CAPSULE

This directory exists so that you do not have to take VERIQO's word for
anything.

Start here:

  1. veriqo-verify .            recomputes every digest, rehashes the
                                ledger from genesis, recomputes the
                                passport digest before checking its
                                signature, and DERIVES the qualification
                                state rather than reading it

  2. assurance/register.txt     the shortest honest account of what is
                                established and what is not

  3. threat-model.json          read the not_considered list first

  4. CONTENTS.json              what this capsule contains, and -- as
                                prominently -- what it does not

What you will find is that VERIQO claims exactly one thing about its own
assurance: INTERNALLY_ASSURED. That is the highest rung reachable
without a party like you, and every rung above it is defined in terms of
work only you can do.

The failure modes VERIQO would most like you to look for are recorded in
assurance/claims.json, each with a disproof path. Two of them have
already produced real defects, found internally and fixed; those are
recorded too, because a disproof path that has produced something is one
we know is capable of producing something.

Nothing here has been examined by anybody outside VERIQO. That is the
whole reason you were sent this.
