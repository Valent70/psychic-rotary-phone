THE WORKED CASE IN THIS CAPSULE IS SYNTHETIC.

It exists so that you can run the Independent Verification Kit against
something rather than against nothing. Without it, six of the kit's
eight steps report UNVERIFIABLE and you are back to reading a document.

What it DOES establish, if it verifies:

  - artefact digests are recomputable from the bytes
  - the ledger chains from genesis and every record rehashes
  - the passport digest is derived from its payload, not asserted
  - a deterministic pipeline step reproduces its recorded output
  - a step that calls a model is marked RECORDED and is NOT claimed to
    have been re-executed

What it establishes about VERIQO's behaviour on REAL data: nothing.
Every byte of it was written by VERIQO to be verified by you. That is
evidence debt ED-007, and it is the reason a real case cannot be put
here yet.

The signing key is fixed in source, at pkg/assurance/capsule. That
would be a serious defect for a production key and is the correct
choice for this one: the capsule must be byte-identical between builds
or you cannot tell a change from a rebuild. The key id says what it is:

  veriqo-demonstration-key-not-a-production-key

It signs one synthetic passport and protects nothing.
